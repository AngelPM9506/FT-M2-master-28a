import React from 'react';
import './App.css';

export default function App() {
  return (
    <div className="App">
      { /* Tu código acá: */ }
      <h1>Título</h1>
    </div>
  );
}
