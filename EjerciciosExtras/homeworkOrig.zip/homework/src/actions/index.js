export const GET_ALL_POSTS = '';
export const GET_ALL_USERS = '';
export const GET_ALL_USERS_POST = '';
export const GET_ALL_COMMENTS_POST = '';

