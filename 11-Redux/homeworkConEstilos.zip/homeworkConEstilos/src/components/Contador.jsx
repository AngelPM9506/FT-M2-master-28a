import { Component } from "react";
/**se importa del metdodo connet de react-redux para mantener en sincronia el state */
import { connect } from "react-redux";
/**las acciones que puede realizar el reducer*/
import { increment, decrement, specific } from '../actions';
/**definicion del componente con todos los demas metodos */
class Contador extends Component {
    constructor(props) {
        super(props);
        this.state = {
            unidades: 0
        }
    }
    /**incrementar solo si es par */
    incrementIfOdd = () => {
        if (this.props.contador % 2 === 0) {
            this.props.increment();
        }
    }
    /**incrementar despues de un segundo */
    incrementAsync = () => {
        setTimeout(() => {
            this.props.increment()
        }, 1000);
    }
    /**numero especifico */
    unitsToIncrement = value => {
        this.setState({ unidades: value });
    }
    render() {
        return (
            <main className="contenedor">
                <section className="datos">
                    <h3>El en numero es:</h3>
                    <h2 className="contador">{this.props.contador}</h2>
                </section>
                <section className="cambiarDatos">
                    <h2>Tarea</h2>
                    <article className="tareas">
                        <button onClick={() => this.props.increment()}>Incrementar</button>
                        <button onClick={() => this.props.decrement()}>Decrementar</button>
                    </article>
                </section>
                <section className="extras">
                    <h2>Extras</h2>
                    <article className="accionesExtras">
                        <div className="accion">
                            <p>Incrementar solo si el numero es par</p>
                            <button onClick={this.incrementIfOdd}>Incrementar</button>
                        </div>
                        <div className="accion">
                            <p>Esperar un segundo para Incrementar</p>
                            <button onClick={this.incrementAsync}>Incrementar</button>
                        </div>
                        <div className="accion">
                            <p>Incrementar unidades especificas</p>
                            <p>Unidades: <span>{this.state.unidades}</span></p>
                            <input type="number" onChange={e => this.unitsToIncrement(parseInt(e.target.value))} />
                            <button onClick={() => this.props.specific(this.state.unidades)}>Incrementar</button>
                        </div>
                    </article>
                </section>
            </main>
        );
    }
}
/**especificar que parte del stado estará monitoreando este componente  */
const mapStateToProps = state => { return { contador: state.contador } };
/**exportar el componente con el metodo connexcion para enlazar redux y el 
 * propio componente
 */
export default connect(mapStateToProps, { increment, decrement, specific })(Contador);