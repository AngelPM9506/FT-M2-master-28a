export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const SPECIFIC = 'SPECIFIC';
/**creador de acciones para el reducer */
export const increment = (value = 1) => {
    return ({ type: INCREMENT });
};

export const decrement = (value = 1) => {
    return ({ type: DECREMENT });
};

export const specific = value => {
    return ({ type: SPECIFIC, value: value });
};