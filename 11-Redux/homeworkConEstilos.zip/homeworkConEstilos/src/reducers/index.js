/**importamos acciones desde el archivo de actions */
import {
    INCREMENT,
    DECREMENT,
    SPECIFIC
} from "../actions";

/**Creamos el estado inicial del store */
const inicialStrore = {
    contador: 0
}

/**se crea del reduce**/
var reduce = (state = inicialStrore, action) => {
    switch (action.type) {
        case INCREMENT:
            return ({
                ...state,
                contador: state.contador + 1
            });
        case DECREMENT:
            return ({
                ...state,
                contador: state.contador - 1
            });
        case SPECIFIC:
            return ({
                ...state,
                contador: state.contador + action.value
            });
        default:
            return state;
    }
};

export default reduce;