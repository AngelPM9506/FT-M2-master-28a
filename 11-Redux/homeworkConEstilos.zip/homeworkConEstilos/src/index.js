/**dependencias de react */
import React from 'react';
import ReactDOM from 'react-dom/client';
/**Estilos */
import './sass/variables.scss';
/**Dependencias de redux */
import { createStore } from 'redux';
import { Provider } from 'react-redux';
/**componenetes */
import Contador from './components/Contador';
/**reducer */
import reduce from './reducers'
/**Crendo el store**/
const store = createStore(reduce);
/**Reenderizado**/
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
    <Contador />
  </Provider>
);
